using System;
using System.Diagnostics;
using System.IO;
using System.Text;

namespace ConsoleApplication1
{

    public class Program
    {

        private const int LOOP_COUNT = 100000;

        public static void Main(string[] args)
        {
            Testar(TestarSoma);
            Testar(TestarConcat);
            Testar(TestarStringBuilder);
            Testar(TestarStream);
        }

        private static void Testar(Func<string> metodo)
        {
            var sw = new Stopwatch();

            Console.Write("Testando {0}... ", metodo.Method.Name);
            sw.Start();
            metodo();
            sw.Stop();
            Console.WriteLine("{0:N0} ms", sw.ElapsedMilliseconds);
        }

        private static string TestarSoma()
        {
            var a = "Um";
            var b = "Dois";
            var c = "Três";
            var d = "";

            for (var ct = 0; ct <= LOOP_COUNT; ct++)
            {
                d += a + b + c;
            }

            return d;
        }

        private static string TestarConcat()
        {
            var a = "Um";
            var b = "Dois";
            var c = "Três";
            var d = "";

            for (var ct = 0; ct <= LOOP_COUNT; ct++)
            {
                d = string.Concat(d, a, b, c);
            }

            return d;
        }

        private static string TestarStringBuilder()
        {
            var a = "Um";
            var b = "Dois";
            var c = "Três";
            var d = new StringBuilder();

            for (var ct = 0; ct <= LOOP_COUNT; ct++)
            {
                d.Append(a);
                d.Append(b);
                d.Append(c);
            }

            return d.ToString();
        }

        private static string TestarStream()
        {
            var a = "Um";
            var b = "Dois";
            var c = "Três";

            using (var ms = new MemoryStream())
            using (var sw = new StreamWriter(ms))
            {
                for (var ct = 0; ct <= LOOP_COUNT; ct++)
                {
                    sw.Write(a);
                    sw.Write(b);
                    sw.Write(c);
                }

                sw.Flush();
                ms.Seek(0, SeekOrigin.Begin);

                using (var sr = new StreamReader(ms))
                {
                    return sr.ReadToEnd();
                }
            }
        }

    }
}