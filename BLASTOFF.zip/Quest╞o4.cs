using System;
public class Fahrenheit
{
  public decimal Value { get; }
  public Fahrenheit(decimal value)
  {
    Value = value;
  }
  // método implicit
  public static implicit operator Celsius(Fahrenheit fahrenheit)
  {
    //°C = (°F − 32) ÷ 5.9
    decimal value = (fahrenheit.Value - 32) / 5.9m;
    return new Celsius(value);
  }
}