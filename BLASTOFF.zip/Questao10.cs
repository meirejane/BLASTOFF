using System.IO;
using System;

class Program
{
    static void Main()

    {
        int fatorial = 10;
        int resultado = 1;
        for (int i = fatorial; i > 1; i--)
        {
            resultado += resultado * (i - 1);
        }
        Console.WriteLine("Fatorial de " + fatorial + ": " + resultado);        

    }
}