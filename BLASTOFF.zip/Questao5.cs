using  System ;

class  MinhaClasse {
  static  void  Main ( string [] args ) {
    string [] valores  =  Console . LeiaLinha (). Dividir ( '' );
    int  A  =  int . Analisar ( valores [ 0 ]);
    int  B  =  int . Analisar ( valores [ 1 ]);

    if ( A  %  B  ==  0  ||  B  %  A  ==  0 ) {
      Consola . WriteLine ( " São Multiplos " );
    }
    senão {
      Consola . WriteLine ( " Nao sao multiplos " );
    }
  }
}