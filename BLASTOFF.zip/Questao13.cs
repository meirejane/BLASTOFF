using System;
int[] array3;
array3 = new int[] { 1, 3, 5, 7, 9 }; 