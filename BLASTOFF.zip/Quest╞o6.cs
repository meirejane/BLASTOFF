using  System ;

class  minhaClasse {
  static  void  Main ( string [] args ) {
    int  diaInicio , diaTermino , horaMomentoInicio , minutoMomentoInicio , segundoMomentoInicio ;
    int  horaMomentoTermino , minutoMomentoTermino , segundoMomentoTerminio ;

    string [] dadosInicio  =  Console . LeiaLinha (). Dividir ( "  " );
    diaInicio  =  Converter . ToInt32 ( dadosInício [ 1 ]);

    string [] dadosMomentoInicio  =  Console . LeiaLinha (). Dividir ( " : " );
    horaMomentoInicio  =  Converter . ToInt32 ( dadosMomentoInicio [ 0 ]);
    minutoMomentoInicio  =  Converter . ToInt32 ( dadosMomentoInicio [ 1 ]);
    segundoMomentoInicio  =  Converter . ToInt32 ( dadosMomentoInicio [ 2 ]);

    string [] dadosTermino  =  Console . LeiaLinha (). Dividir ( "  " );
    diaTermino  =  Converter . ToInt32 ( dadosTermino [ 1 ]);

    string [] dadosMomentoTermino  =  Console . LeiaLinha (). Dividir ( " : " );
    horaMomentoTermino  =  Converter . ToInt32 ( dadosMomentoTermino [ 0 ]);
    minutoMomentoTermino  =  Converter . ToInt32 ( dadosMomentoTermino [ 1 ]);
    segundoMomentoTerminio  =  Converter . ToInt32 ( dadosMomentoTermino [ 2 ]);

    int  Segundo  = ( segundoMomentoTerminio  -  segundoMomentoInicio );
    int  Minuto  = ( minutoMomentoTermino  -  minutoMomentoInicio );
    int  Hora  = ( horaMomentoTermino  -  horaMomentoInicio );
    int  Dia  = ( diaTermino  -  diaInicio );

    if ( Segundo  <  0 ) {
      Segundo  +=  60 ;
      Minuto -- ;
    }

    if ( Minuto  <  0 ) {
      Minuto  +=  60 ;
      Hora -- ;
    }

    if ( Hora  <  0 ) {
      Hora  +=  24 ;
      Dia -- ;
    }

    Consola . WriteLine ( Dia  +  " dia(s) " );
    Consola . WriteLine ( Hora  +  " hora(s) " );
    Consola . WriteLine ( Minuto  +  " minuto(s) " );
    Consola . WriteLine ( Segundo  +  " segundo(s) " );
  }
}