using  System;

classe  ConsumoMedioDoAutomovel
{
    static  void  Main ( string [] args )
    {
        int  distancia ;
        duplo  combustivelGasto , consumoMedio ;

        distancia  =  Converter . ToInt32 ( Console . ReadLine ());
        combustivelGasto  =  Converter . ToDouble ( Console . ReadLine ());

        consumoMedio  =  distancia  /  combustivelGasto ;

        Consola . WriteLine ( " {0:0.000} km/l " , consumoMedio );
    }
}