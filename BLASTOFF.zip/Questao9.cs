using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    programa de aula
    {
        static void Main(string[] args)
        {

            // Recebe como Variáveis
            int formula, contador, numero;

           
            Console.Write("Digite o Número para Obter a Taboada : ");
            numero = Int32.Parse(Console.ReadLine());

            //pára
            for (contador = 1; contador <= 10; ++contador)
            {
                formula = numero * contador;
                Console.WriteLine(numero + " X " + contador + " = " + formula);
                
            }

            Console.ReadKey();
        }

    }
}